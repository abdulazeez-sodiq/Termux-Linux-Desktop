### Welcome to the documentation! 👋

📁 **Explore Different Folders:**

- 📂 **native:** Check out for native Termux information.
- 📂 **proot:** Dive into PROOT-DISTRO environment details.
- 📂 **chroot** Explore CHROOT environment specifics.

Feel free to explore each folder to discover more! Don't hesitate to reach out if you have any questions or suggestions 🚀
